//
//  GoogleFontModel.m
//  GoogleFontModel
//
//  Created by duke.kuo on 2018/9/13.
//  Copyright © 2018年 Test. All rights reserved.
//

#import "GoogleFontModel.h"

NSString *const GoogleFontVariantKey_Regular = @"regular";
NSString *const GoogleFontVariantKey_Bold = @"700";
NSString *const GoogleFontVariantKey_Italic = @"italic";
NSString *const GoogleFontVariantKey_BoldItalic = @"700italic";

@implementation GoogleFontModel

//================================================================================
//
//================================================================================
- (void)dealloc
{
    self.family = nil;
    self.category = nil;
    self.subsets = nil;
    self.variants = nil;
    self.version = nil;
    self.lastModified = nil;
    self.files = nil;
    self.localFiles = nil;
    
    [super dealloc];
}





////////////////////////////////////////////////////////////////////////////////////////////////////

#pragma mark - Private

//================================================================================
//
//================================================================================
- (NSURL *)localFileURLWithVariant:(NSString *)variant
{
    NSString *fontFamily = [self.family stringByReplacingOccurrencesOfString:@" "
                                                                  withString:@""];
    NSString *resultFileName = [NSString stringWithFormat:@"%@-%@", fontFamily, variant];
    NSString *documentURLPath = [[self applicationDocumentsDirectory] path];
    NSString *resultFilePath = [documentURLPath stringByAppendingPathComponent:resultFileName];
    NSURL *resultTTFURL = [NSURL fileURLWithPath:resultFilePath];
    NSLog(@"resultTTFURL:%@", resultTTFURL);
    
    return resultTTFURL;
}


//================================================================================
//
//================================================================================
- (NSURL *)applicationDocumentsDirectory
{
    return [[[NSFileManager defaultManager] URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask] lastObject];
}





////////////////////////////////////////////////////////////////////////////////////////////////////

#pragma mark - Instance Methods

//================================================================================
//
//================================================================================
- (BOOL)isNeedToDownloadTTFFile
{
    BOOL result = NO;
    for (NSString *variant in [self.localFiles allKeys])
    {
        if ([self isNeedToDownloadTTFFileWithVariant:variant])
        {
            result = YES;
            break;
        }
    }
    
    return result;
}


//================================================================================
//
//================================================================================
- (BOOL)isNeedToDownloadTTFFileWithVariant:(NSString *)variant
{
    NSURL *fileURL = [self.localFiles objectForKey:variant];
    if ([[NSFileManager defaultManager] fileExistsAtPath:[fileURL path]] == NO)
    {
        return YES;
    }
    
    return NO;
}


//================================================================================
//
//================================================================================
- (NSArray *)variantsNeedToDownloadTTF
{
    NSMutableArray *variantsNeedToDownloadTTF = [NSMutableArray array];
    for (NSString *variant in [self.localFiles allKeys])
    {
        if ([self isNeedToDownloadTTFFileWithVariant:variant])
        {
            [variantsNeedToDownloadTTF addObject:variant];
        }
    }
    
    return variantsNeedToDownloadTTF;
}





////////////////////////////////////////////////////////////////////////////////////////////////////

#pragma mark - Class Method - Google Font Model Factory



//================================================================================
//
//================================================================================
+ (GoogleFontModel *)fontWithDictionary:(NSDictionary *)fontDictionary
{
    GoogleFontModel *font = [[[GoogleFontModel alloc] init] autorelease];
    
    if (font == nil)
    {
        return nil;
    }
    
    font.family = [fontDictionary objectForKey:@"family"];
    font.category = [fontDictionary objectForKey:@"category"];
    font.subsets = [fontDictionary objectForKey:@"subsets"];
    font.variants = [fontDictionary objectForKey:@"variants"];
    font.version = [fontDictionary objectForKey:@"version"];
    font.lastModified = [fontDictionary objectForKey:@"lastModified"];
    font.files = [fontDictionary objectForKey:@"files"];
    font.localFiles = [NSMutableDictionary dictionary];
    for (NSString *variant in font.variants)
    {
        NSURL *localFilePath = [font localFileURLWithVariant:variant];
        [font.localFiles setObject:localFilePath forKey:variant];
    }
    
    return font;
}


//================================================================================
//
//================================================================================
+ (NSArray *)defaultVariantsList
{
    NSArray *defaultVariantsList = @[GoogleFontVariantKey_Regular,
                                     GoogleFontVariantKey_Bold,
                                     GoogleFontVariantKey_Italic,
                                     GoogleFontVariantKey_BoldItalic];
    
    return defaultVariantsList;
}

@end
