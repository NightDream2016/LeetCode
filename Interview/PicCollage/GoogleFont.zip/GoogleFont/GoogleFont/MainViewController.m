//
//  MainViewController.m
//  GoogleFont
//
//  Created by duke.kuo on 2018/9/13.
//  Copyright © 2018年 Test. All rights reserved.
//

#import "MainViewController.h"
#import "FontPreviewViewController.h"

@interface MainViewController ()

@end

@implementation MainViewController

//================================================================================
//
//================================================================================
- (IBAction)testButtonClicked:(id)sender
{
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main"
                                                         bundle:[NSBundle mainBundle]];
    FontPreviewViewController *viewController = (FontPreviewViewController *)[storyboard instantiateViewControllerWithIdentifier:@"FrontPreviewViewController"];
    viewController.isPreviewFontByCell = NO;
    [self presentViewController:viewController animated:YES completion:nil];
}


//================================================================================
//
//================================================================================
- (IBAction)testButtonWithAysnchonrousShowCellStyleClicked:(id)sender
{
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main"
                                                         bundle:[NSBundle mainBundle]];
    FontPreviewViewController *viewController = (FontPreviewViewController *)[storyboard instantiateViewControllerWithIdentifier:@"FrontPreviewViewController"];
    viewController.isPreviewFontByCell = YES;
    viewController.isShowCellFontAysnchonrous = YES;
    [self presentViewController:viewController animated:YES completion:nil];
}


//================================================================================
//
//================================================================================
- (IBAction)testButtonWithSynchonrousShowCellStyleClicked:(id)sender
{
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main"
                                                         bundle:[NSBundle mainBundle]];
    FontPreviewViewController *viewController = (FontPreviewViewController *)[storyboard instantiateViewControllerWithIdentifier:@"FrontPreviewViewController"];
    viewController.isPreviewFontByCell = YES;
    viewController.isShowCellFontAysnchonrous = NO;
    [self presentViewController:viewController animated:YES completion:nil];
}

@end
