//
//  AppDelegate.h
//  GoogleFont
//
//  Created by duke.kuo on 2018/9/12.
//  Copyright © 2018年 Test. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (retain, nonatomic) UIWindow *window;


@end

