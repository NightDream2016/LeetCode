//
//  GoogleFontModel.h
//  GoogleFontModel
//
//  Created by duke.kuo on 2018/9/13.
//  Copyright © 2018年 Test. All rights reserved.
//

#import <Foundation/Foundation.h>

extern NSString *const GoogleFontVariantKey_Regular;
extern NSString *const GoogleFontVariantKey_Bold;
extern NSString *const GoogleFontVariantKey_Italic;
extern NSString *const GoogleFontVariantKey_BoldItalic;

@interface GoogleFontModel : NSObject





////////////////////////////////////////////////////////////////////////////////////////////////////

#pragma mark - Property

@property (nonatomic, retain) NSString *family;
@property (nonatomic, retain) NSString *category;
@property (nonatomic, retain) NSArray *subsets;
@property (nonatomic, retain) NSArray *variants;
@property (nonatomic, retain) NSString *version;
@property (nonatomic, retain) NSString *lastModified;
@property (nonatomic, retain) NSDictionary *files;

/**
 記錄ttf檔下載到本地端後的路徑
 */
@property (nonatomic, retain) NSMutableDictionary *localFiles;





////////////////////////////////////////////////////////////////////////////////////////////////////

#pragma mark - Instance Method

/**
 是否需要下載字型檔以顯示

 @return YES Or NO To Need Corresond TTF File
 */
- (BOOL)isNeedToDownloadTTFFile;

/**
 檢查特定Variant之TTF是否需要下載

 @param variant GoogleFontVariantKey
 @return YES Or NO To Need Corresond TTF File
 */
- (BOOL)isNeedToDownloadTTFFileWithVariant:(NSString *)variant;

/**
 回傳需要下載TTF的Variant

 @return Array Of Variant String Need To Download;
 */
- (NSArray *)variantsNeedToDownloadTTF;




////////////////////////////////////////////////////////////////////////////////////////////////////

#pragma mark - Class Methods - Factory

+ (GoogleFontModel *)fontWithDictionary:(NSDictionary *)fontDictionary;





////////////////////////////////////////////////////////////////////////////////////////////////////

#pragma mark - Class Methods - Utility

+ (NSArray *)defaultVariantsList;

@end
