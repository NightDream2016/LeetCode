//
//  FontPreviewViewController.m
//  GoogleFont
//
//  Created by kuo on 2018/9/12.
//  Copyright © 2018年 Test. All rights reserved.
//

#import "FontPreviewViewController.h"
#import "GoogleFontModel.h"
#import "UIFont-TTF.h"
#import <CoreText/CoreText.h>





////////////////////////////////////////////////////////////////////////////////////////////////////

#pragma mark - Predefine

static NSString *const GoogleFontAPIKey = @"AIzaSyDQKr3hZrYQ_xoS96BxTo34Xnc9yVbnUDo";
static NSString *const GoogleFontAPIURLTemplate = @"https://www.googleapis.com/webfonts/v1/webfonts?key=%@";
static NSString *const ReuseableIdentifierOfFontTableViewCell = @"ReuseableIdentifierOfFontTableViewCell";

static NSString *const FontMessageTemplate = @"Version:%@ Last Modified:%@";

static CGFloat const GoogleFontVariant_PreviewFontSize = 48;
static CGFloat const GoogleFontVariant_CellFontSize = 20;

typedef void(^NSURLSessionDataTaskCompletionHandler)(NSData * _Nullable data,
                                                     NSURLResponse * _Nullable
                                                     response, NSError * _Nullable error);




////////////////////////////////////////////////////////////////////////////////////////////////////

#pragma mark - FontPreviewViewController Interface

@interface FontPreviewViewController () <UITableViewDelegate, UITableViewDataSource, NSURLSessionDownloadDelegate>

@property (nonatomic, retain) NSMutableDictionary *fontListDictionary;

@property (nonatomic, retain) IBOutlet UITableView *fontTableView;
@property (nonatomic, retain) IBOutlet UIActivityIndicatorView *busyIndicator;
@property (nonatomic, retain) IBOutlet UILabel *fontPreviewLabel;
@property (nonatomic, retain) IBOutlet UILabel *fontInformationLabel;
@property (nonatomic, retain) IBOutlet UISegmentedControl *variantsegment;

@property (nonatomic, retain) GoogleFontModel *currentSelectedFont;

@end





////////////////////////////////////////////////////////////////////////////////////////////////////

#pragma mark - FontPreviewViewController Implementation


@implementation FontPreviewViewController

//================================================================================
//
//================================================================================
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    //////////////////////////////////////////////////
    
    self.fontListDictionary = [NSMutableDictionary dictionary];
    self.currentSelectedFont = nil;
    self.fontPreviewLabel.numberOfLines = 1;
    self.fontPreviewLabel.adjustsFontSizeToFitWidth = YES;
}


//================================================================================
//
//================================================================================
- (void)dealloc
{
    self.fontListDictionary = nil;
    self.currentSelectedFont = nil;
    
    self.fontTableView = nil;
    self.busyIndicator = nil;
    self.fontPreviewLabel = nil;
    self.fontInformationLabel = nil;
    self.variantsegment = nil;
    
    //////////////////////////////////////////////////
    
    [super dealloc];
}





////////////////////////////////////////////////////////////////////////////////////////////////////

#pragma mark - Resonding To View Events


//================================================================================
//
//================================================================================
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    //////////////////////////////////////////////////
    
    [self refreshVariantSegment];
    [self refreshFontPreview];
    [self readGoogleFontList];
}


//================================================================================
//
//================================================================================
- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    [[NSURLSession sharedSession] getTasksWithCompletionHandler:^(NSArray<NSURLSessionDataTask *> * _Nonnull dataTasks, NSArray<NSURLSessionUploadTask *> * _Nonnull uploadTasks, NSArray<NSURLSessionDownloadTask *> * _Nonnull downloadTasks)
    {
        for (NSURLSessionDataTask *task in dataTasks)
        {
            [task cancel];
        }
        
        for (NSURLSessionDataTask *task in downloadTasks)
        {
            [task cancel];
        }
        
    }];
}





////////////////////////////////////////////////////////////////////////////////////////////////////

#pragma mark - Private

//================================================================================
//
//================================================================================
- (NSArray *)fontListArray
{
    if (self.fontListDictionary == nil || [[self.fontListDictionary allValues] count] == 0)
    {
        return @[];
    }
    
    NSMutableArray *fontListArray = [NSMutableArray array];
    [fontListArray addObjectsFromArray:[self.fontListDictionary allValues]];
    [fontListArray sortUsingComparator:^NSComparisonResult(id  _Nonnull obj1, id  _Nonnull obj2) {
        GoogleFontModel *fontModelA = (GoogleFontModel *)obj1;
        GoogleFontModel *fontModelB = (GoogleFontModel *)obj2;
        
        return [fontModelA.family compare:fontModelB.family];
    }];
    return fontListArray;
}


//================================================================================
//
//================================================================================
- (void)readGoogleFontList
{
    NSURLSessionDataTaskCompletionHandler completionHandler = ^(NSData * _Nullable data,
                                                                NSURLResponse * _Nullable response,
                                                                NSError * _Nullable error)
    {
        if (error != nil)
        {
            [self showDownloadFailedAlertWithAction:^(UIAlertAction *action) {
                [self dismissViewControllerAnimated:YES completion:nil];
            }];
            return;
        }
        
        NSError *jsonReadError;
        NSDictionary *jsonResultDictionary = [NSJSONSerialization JSONObjectWithData:data
                                                                             options:NSJSONReadingMutableLeaves
                                                                               error:&jsonReadError];
        NSLog(@"%@", jsonResultDictionary);
        
        NSArray *fontItemArray = [jsonResultDictionary objectForKey:@"items"];
        
        for (NSDictionary *fontDictionary in fontItemArray)
        {
            if ([[fontDictionary objectForKey:@"kind"] isEqualToString:@"webfonts#webfont"])
            {
                GoogleFontModel *model = [GoogleFontModel fontWithDictionary:fontDictionary];
                [self.fontListDictionary setObject:model forKey:model.family];
            }
        }
        
        if (self.isPreviewFontByCell)
        {
            if (self.isShowCellFontAysnchonrous == NO)
            {
                [self downloadAllNeededFontFile];
                return;
            }
        }
        
        dispatch_async(dispatch_get_main_queue(), ^{
            [self showBusyIndicator:NO];
            [self.fontTableView setHidden:NO];
            [self.fontTableView reloadData];
        });
    };
    
    [self showBusyIndicator:YES];
    [self.fontTableView setHidden:YES];
    
    NSString *apiURLString = [NSString stringWithFormat:GoogleFontAPIURLTemplate, GoogleFontAPIKey];
    
    NSURL *apiURL = [NSURL URLWithString:apiURLString];
    NSURLRequest *apiURLRequest = [NSURLRequest requestWithURL:apiURL];

    NSURLSession *session = [NSURLSession sharedSession];
    
    NSURLSessionDataTask *dataTask =  [session dataTaskWithRequest:apiURLRequest
                                                 completionHandler:completionHandler];
    
    [dataTask resume];
}





////////////////////////////////////////////////////////////////////////////////////////////////////

#pragma mark - Private - Download All Font File

//================================================================================
// 用在同步下載Font TTF，會跳出BusyView擋住使用者並一次抓完FontModel再讓使用者開始使用。
//================================================================================
- (void)downloadAllNeededFontFile
{
    if (self.isShowCellFontAysnchonrous)
    {
        return;
    }
    
    NSMutableArray *fontModelNeedToDownload = [[NSMutableArray alloc] init];
    for (GoogleFontModel *fontModel in [self fontListArray])
    {
        if ([fontModel isNeedToDownloadTTFFile])
        {
            [fontModelNeedToDownload addObject:fontModel];
        }
    }
    
    if ([fontModelNeedToDownload count] == 0)
    {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self showBusyIndicator:NO];
            [self.fontTableView setHidden:NO];
            [self.fontTableView reloadData];
        });
        return;
    }
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.fontInformationLabel setText:@""];
        [self.fontInformationLabel setHidden:NO];
    });
    
    for (GoogleFontModel *fontModel in fontModelNeedToDownload)
    {
        [self downloadNeededFontFileWithModel:fontModel
                            completionHandler:^(NSURL * _Nullable resultTTFURL, NSError * _Nullable error)
         {
             [fontModelNeedToDownload removeObject:fontModel];
             
             dispatch_async(dispatch_get_main_queue(), ^{
                 NSInteger countOfRemainFont = [fontModelNeedToDownload count];
                 NSString *message = [NSString stringWithFormat:@"Remain %ld Font To Download.", (long)countOfRemainFont];
                 [self.fontInformationLabel setText:message];
             });
             
             if ([fontModelNeedToDownload count] == 0)
             {
                 dispatch_async(dispatch_get_main_queue(), ^{
                     [self.fontInformationLabel setText:@""];
                     [self showBusyIndicator:NO];
                     [self.fontTableView setHidden:NO];
                     [self.fontTableView reloadData];
                 });
             }
         }];
    }
}






////////////////////////////////////////////////////////////////////////////////////////////////////

#pragma mark - Private - Downlaod TTF Related

//================================================================================
// 檢查FontModel需要下載的TTF (補足還沒下載的Variant)
//================================================================================
- (void)downloadNeededFontFileWithModel:(GoogleFontModel *)fontModel
                      completionHandler:(void (^_Nullable)(NSURL  * _Nullable resultTTFURL,
                                                           NSError * _Nullable error))completionHandler;
{
    for (NSString *variant in [fontModel variantsNeedToDownloadTTF])
    {
        [self downloadFontModelTTFFile:fontModel
                           withVariant:variant
                     completionHandler:^(NSURL * _Nullable resultTTFURL, NSError * _Nullable error)
        {
            if ([fontModel isNeedToDownloadTTFFile] == NO)
            {
                completionHandler(resultTTFURL, error);
            }
        }];
    }
}


//================================================================================
// 下載FontModel特定Variant的File
//================================================================================
- (void)downloadFontModelTTFFile:(GoogleFontModel *)fontModel
                     withVariant:(NSString *)variant
               completionHandler:(void (^_Nullable)(NSURL  * _Nullable resultTTFURL,
                                                    NSError * _Nullable error))completionHandler;
{
    NSString *fontFileURLString = [fontModel.files objectForKey:variant];
    NSURL *fontFileURL = [NSURL URLWithString:fontFileURLString];
    NSURLSession *session = [NSURLSession sharedSession];
    
    NSURLSessionDownloadTask *task = [session downloadTaskWithURL:fontFileURL
                                                completionHandler:^(NSURL * _Nullable location,
                                                                    NSURLResponse * _Nullable response,
                                                                    NSError * _Nullable error)
                                      {
                                          NSURL *resultTTFURL = [fontModel.localFiles objectForKey:variant];
                                          if (location)
                                          {
                                              [[NSFileManager defaultManager] copyItemAtURL:location
                                                                                      toURL:resultTTFURL
                                                                                      error:nil];
                                          }
                                          
                                          completionHandler(resultTTFURL, error);
                                      }];

    [task resume];
}





////////////////////////////////////////////////////////////////////////////////////////////////////

#pragma mark - Private - UI Related


//================================================================================
//
//================================================================================
- (void)refreshFontPreview
{
    dispatch_async(dispatch_get_main_queue(), ^{
        
        GoogleFontModel *fontModel = self.currentSelectedFont;
        
        if (fontModel == nil)
        {
            [self.fontPreviewLabel setHidden:YES];
            [self.fontInformationLabel setHidden:YES];
            return;
        }
        
        NSURL *regularFontURL = [fontModel.localFiles objectForKey:GoogleFontVariantKey_Regular];
        UIFont *font = [UIFont fontWithTTFAtURL:regularFontURL size:GoogleFontVariant_PreviewFontSize];
        
        [self.fontPreviewLabel setFont:font];
        
        NSString *fontMessage = [NSString stringWithFormat:FontMessageTemplate,
                                 fontModel.version,
                                 fontModel.lastModified];
        
        [self.fontPreviewLabel setText:fontModel.family];
        [self.fontPreviewLabel setHidden:NO];
        [self.fontInformationLabel setText:fontMessage];
        [self.fontInformationLabel setHidden:NO];
        [self showBusyIndicator:NO];
    });
}


//================================================================================
//
//================================================================================
- (void)refreshVariantSegment
{
    GoogleFontModel *fontModel = self.currentSelectedFont;
    
    if (fontModel == nil)
    {
        for (NSInteger index = 0; index <self.variantsegment.numberOfSegments; index++ )
        {
            [self.variantsegment setEnabled:NO forSegmentAtIndex:index];
        }
        
        return;
    }
    
    NSDictionary *variantFiles = fontModel.files;
    
    NSArray *defaultVariantList = [GoogleFontModel defaultVariantsList];
    for (NSString *variant in defaultVariantList)
    {
        NSInteger segmentIndex = [defaultVariantList indexOfObject:variant];
        if ([variantFiles objectForKey:variant] == nil)
        {
            [self.variantsegment setEnabled:NO forSegmentAtIndex:segmentIndex];
        }
        else
        {
            [self.variantsegment setEnabled:YES forSegmentAtIndex:segmentIndex];
        }
    }
    
    [self.variantsegment setSelectedSegmentIndex:0];
}


//================================================================================
//
//================================================================================
- (void)showDownloadFailedAlertWithAction:(void(^ __nullable)(UIAlertAction *action))action
{
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Data Download Failed."
                                                                   message:@"Please Check Your Internet Connection"
                                                            preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *defaultAction = [UIAlertAction actionWithTitle:@"OK"
                                                            style:UIAlertActionStyleDefault
                                                          handler:action];
    [alert addAction:defaultAction];
    [self presentViewController:alert animated:YES completion:nil];
}


//================================================================================
//
//================================================================================
- (void)showBusyIndicator:(BOOL)isShow
{
    if (isShow)
    {
        [self.busyIndicator setHidden:NO];
        [self.busyIndicator startAnimating];
    }
    else
    {
        [self.busyIndicator stopAnimating];
        [self.busyIndicator setHidden:YES];
    }
}





////////////////////////////////////////////////////////////////////////////////////////////////////

#pragma mark - Action

//================================================================================
//
//================================================================================
- (IBAction)onFontVariantChanged:(id)sender
{
    NSInteger selectedSegmentIndex = [sender selectedSegmentIndex];
    NSArray *defaultVariantList = [GoogleFontModel defaultVariantsList];
    
    NSString *fontVarientKey = [defaultVariantList objectAtIndex:selectedSegmentIndex];
    NSURL *fontFileURL = [self.currentSelectedFont.localFiles objectForKey:fontVarientKey];
    
    UIFont *preivewFont = [UIFont fontWithTTFAtURL:fontFileURL size:GoogleFontVariant_PreviewFontSize];
    [self.fontPreviewLabel setFont:preivewFont];
}


//================================================================================
//
//================================================================================
- (IBAction)onBackButtonClicked:(id)sender
{
    [self dismissViewControllerAnimated:YES completion:nil];
}




////////////////////////////////////////////////////////////////////////////////////////////////////

#pragma mark - UITableViewDataSource

//================================================================================
//
//================================================================================
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}


//================================================================================
//
//================================================================================
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self fontListArray].count;
}


//================================================================================
//
//================================================================================
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    
    GoogleFontModel *fontModel = [[self fontListArray] objectAtIndex:indexPath.row];
    NSString *fontFamily = fontModel.family;
    
    UITableViewCell *fontTableViewCell = [tableView dequeueReusableCellWithIdentifier:ReuseableIdentifierOfFontTableViewCell];
    
    if(fontTableViewCell == nil)
    {
        fontTableViewCell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:ReuseableIdentifierOfFontTableViewCell] autorelease];
    }
    
    [fontTableViewCell.textLabel setText:fontFamily];
    
    do
    {
        if (self.isPreviewFontByCell == NO)
        {
            [fontTableViewCell.textLabel setFont:[UIFont systemFontOfSize:GoogleFontVariant_CellFontSize]];
            break;
        }
        
        if ([fontModel isNeedToDownloadTTFFile] == NO)
        {
            NSURL *fontURL = [fontModel.localFiles objectForKey:GoogleFontVariantKey_Regular];
            UIFont *font = [UIFont fontWithTTFAtURL:fontURL size:GoogleFontVariant_CellFontSize];
            [fontTableViewCell.textLabel setFont:font];
            break;
        }
        
        [self downloadFontModelTTFFile:fontModel
                           withVariant:GoogleFontVariantKey_Regular
                     completionHandler:^(NSURL *_Nullable resultTTFURL, NSError * _Nullable error)
         {
             NSInteger row = [[self fontListArray] indexOfObject:fontModel];
             NSIndexPath *indexPath = [NSIndexPath indexPathForRow:row inSection:0];
             
             dispatch_async(dispatch_get_main_queue(), ^{
                 
                 UITableViewCell *cell = [self.fontTableView cellForRowAtIndexPath:indexPath];
                 
                 if ([cell.textLabel.text isEqualToString:fontModel.family])
                 {
                     [cell.textLabel setFont:[UIFont fontWithTTFAtURL:resultTTFURL size:GoogleFontVariant_CellFontSize]];
                 }
                 
             });
         }];
    }
    while (NO);
    
    return fontTableViewCell;
}


//================================================================================
//
//================================================================================
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 60;
}





////////////////////////////////////////////////////////////////////////////////////////////////////

#pragma mark - UITableViewDelegte

//================================================================================
//
//================================================================================
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self showBusyIndicator:YES];
    [self.fontPreviewLabel setHidden:YES];
    
    GoogleFontModel *fontModel = [[self fontListArray] objectAtIndex:indexPath.row];
    self.currentSelectedFont = fontModel;
    
    [self refreshVariantSegment];
    
    if ([fontModel isNeedToDownloadTTFFile])
    {
        [self downloadNeededFontFileWithModel:fontModel
                            completionHandler:^(NSURL * _Nullable resultTTFURL,
                                                NSError * _Nullable error)
        {
            if (error != nil)
            {
                [self showDownloadFailedAlertWithAction:nil];
                return;
            }
            
            [self refreshFontPreview];
        }];
    }
    else
    {
        [self refreshFontPreview];
    }
}



@end
