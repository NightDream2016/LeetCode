//
//  FontPreviewViewController.h
//  GoogleFont
//
//  Created by duke.kuo on 2018/9/12.
//  Copyright © 2018年 Test. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FontPreviewViewController : UIViewController

/**
 是否啟用Cell直接預覽字型，若不使用，字型檔會在點擊Cell時才下載
 */
@property (nonatomic, assign) BOOL isPreviewFontByCell;

/**
 是否先顯示預設字型Cell，待下載完TTF後Cell才顯示正確的字型
 若isPreviewFontByCell為NO此Property為無效
 若設為NO則會等下載完所有字型後才讓使用者開始使用
 */
@property (nonatomic, assign) BOOL isShowCellFontAysnchonrous;

@end
